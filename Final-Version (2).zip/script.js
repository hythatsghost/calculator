// Variable to keep track of the number of comps added
let compCount = 0;

// Function to add a comp
function addComp() {
    // Check if the maximum number of comps (5) has not been reached
    if (compCount < 5) {
        compCount++;
        const compsContainer = document.getElementById("comps");
        const newComp = document.createElement("div");
        newComp.classList.add("comp");
        newComp.innerHTML = `
            <label for="comp${compCount}price">Comp ${compCount} Price:</label>
            <input type="number" id="comp${compCount}price" placeholder="Sold Price" oninput="calculateARVMAO()">
            <input type="number" id="comp${compCount}sqft" placeholder="Square Footage" oninput="calculateARVMAO()">
            <select id="comp${compCount}adjustmentType" onchange="calculateARVMAO()">
                <option value="none">No Adjustment</option>
                <option value="set">Set Amount</option>
                <option value="percentage">Percentage</option>
            </select>
            <input type="number" id="comp${compCount}adjustmentValue" placeholder="Adjustment Value" oninput="calculateARVMAO()">
        `;
        compsContainer.appendChild(newComp);
    }
}

// Function to calculate ARV and MAO
function calculateARVMAO() {
    // Extract information about comps
    const comps = Array.from(document.querySelectorAll(".comp")).reduce((acc, comp, index) => {
        const soldPrice = parseFloat(comp.querySelector(`#comp${index + 1}price`).value) || 0;
        const squareFeet = parseFloat(comp.querySelector(`#comp${index + 1}sqft`).value) || 0;
        const adjustmentType = comp.querySelector(`#comp${index + 1}adjustmentType`).value;
        const adjustmentValue = parseFloat(comp.querySelector(`#comp${index + 1}adjustmentValue`).value) || 0;

        let adjustedPrice = soldPrice;
        if (adjustmentType === 'set') {
            adjustedPrice += adjustmentValue;
        } else if (adjustmentType === 'percentage') {
            adjustedPrice *= (1 + adjustmentValue / 100);
        }

        if (!isNaN(soldPrice) && !isNaN(squareFeet)) { // Check for NaN responses
            acc.push({ soldPrice: adjustedPrice, squareFeet });
        }

        return acc;
    }, []);

    // Extract information from input fields
    const repairCosts = parseFloat(document.getElementById("repairCosts").value) || 0;
    const profitMargin = parseFloat(document.getElementById("profitMargin").value) / 100 || 0;
    const wholesaleFee = parseFloat(document.getElementById("wholesaleFee").value) || 0;
    const closingCostsPercentage = parseFloat(document.getElementById("closingCostsPercentage").value) || 0;
    const subjectSquareFoot = parseFloat(document.getElementById("subjectSquareFoot").value) || 0;
    const subjectAddress = document.getElementById("subjectAddress").value;

    // Calculate ARV
    const averagePricePerSqFt = comps.length > 0 ? comps.reduce((sum, comp) => sum + comp.soldPrice / comp.squareFeet, 0) / comps.length : 0;
    const arv = averagePricePerSqFt * subjectSquareFoot;

    // Calculate MAO
    const mao = arv * (1 - profitMargin) - repairCosts - wholesaleFee;
    const closingCosts = (mao + wholesaleFee) * (closingCostsPercentage / 100);
    const buyPrice = mao + wholesaleFee;
    const potentialProfit = arv - buyPrice - repairCosts - closingCosts;

    // Display results
    const arvMaoResults = document.querySelector(".arv-mao-results");
    arvMaoResults.innerHTML = `
        <p>Subject Property: Address: ${subjectAddress}</p>
        <p>ARV: $${arv.toFixed(2)}</p>
        <p>MAO: $${mao.toFixed(2)}</p>
        <p>Average Sold Price: $${(arv / subjectSquareFoot).toFixed(2)}</p>
        <p>Repair Costs: $${repairCosts.toFixed(2)}</p>
        <p>Wholesale Fee: $${wholesaleFee.toFixed(2)}</p>
        <p>Buy Price (including Wholesale Fee): $${buyPrice.toFixed(2)}</p>
        <p>Potential Flip Profit: $${potentialProfit.toFixed(2)}</p>
        <p>Total Estimated Costs: $${(repairCosts + closingCosts + buyPrice).toFixed(2)}</p>
    `;

    // Update closing costs percentage value
    const closingCostsPercentageValue = document.getElementById("closingCostsPercentageValue");
    closingCostsPercentageValue.textContent = closingCostsPercentage;
}

// Function to reset ARV and MAO Calculator
function resetARVMAO() {
    if (confirm('Are you sure you want to reset the ARV and MAO Calculator?')) {
        // Reset comp count and clear comps container
        compCount = 0;
        const compsContainer = document.getElementById("comps");
        compsContainer.innerHTML = "";

        // Clear input fields and results
        document.getElementById("subjectAddress").value = "";
        document.getElementById("subjectSquareFoot").value = "";
        document.getElementById("repairCosts").value = "";
        document.getElementById("profitMargin").value = "";
        document.getElementById("wholesaleFee").value = "";
        document.getElementById("closingCostsPercentage").value = 0;
        document.getElementById("closingCostsPercentageValue").textContent = "0";
        document.querySelector(".arv-mao-results").innerHTML = "";
    }
}

// Function to calculate seller financing
function calculateSellerFinancing() {
    // Extract information from input fields
    const downPaymentPercentage = parseFloat(document.getElementById("downPayment").value);
    const buyPrice = parseFloat(document.getElementById("buyPrice").value) || 0;
    const downPayment = (downPaymentPercentage / 100) * buyPrice;
    const totalLoanAmount = buyPrice - downPayment;
    const interestRate = parseFloat(document.getElementById("interestRate").value) || 0;
    const loanTerm = parseInt(document.getElementById("loanTerm").value) || 0;
    const monthlyInterestRate = interestRate / (12 * 100);
    const numberOfPayments = loanTerm * 12;
    const monthlyPayment =
        (totalLoanAmount * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, numberOfPayments)) /
        (Math.pow(1 + monthlyInterestRate, numberOfPayments) - 1);
    const totalInterestPaid = monthlyPayment * numberOfPayments - totalLoanAmount;

    // Display results
    const sellerFinancingResults = document.querySelector(".seller-financing-results");
    sellerFinancingResults.innerHTML = `
        <p>Buy Price: $${buyPrice.toFixed(2)}</p>
        <p>Interest Rate: ${interestRate}%</p>
        <p>Loan Term: ${loanTerm} years</p>
        <p>Down Payment Type: ${downPaymentPercentage}%</p>
        <p>Down Payment Amount: $${downPayment.toFixed(2)}</p>
        <p>Total Loan Amount: $${totalLoanAmount.toFixed(2)}</p>
        <p>Monthly Payment: $${monthlyPayment.toFixed(2)}</p>
        <p>Total Interest Paid: $${totalInterestPaid.toFixed(2)}</p>
    `;

    // Update down payment value display
    updateDownPaymentValue();
}

// Function to reset Seller Financing Calculator
function resetSellerFinancing() {
    if (confirm('Are you sure you want to reset the Seller Financing Calculator?')) {
        // Clear input fields
        document.getElementById("buyPrice").value = "";
        document.getElementById("interestRate").value = "";
        document.getElementById("loanTerm").value = "";
        document.getElementById("downPayment").value = "10";
        document.getElementById("downPaymentValue").textContent = "10%";
        calculateSellerFinancing(); // Recalculate after reset
    }
}

// Function to update the displayed value for the down payment percentage slider
function updateDownPaymentValue() {
    var slider = document.getElementById("downPayment");
    var valueDisplay = document.getElementById("downPaymentValue");
    valueDisplay.textContent = slider.value + "%";
}

// Sound effects
const clickSound = new Audio('75235__creek23__cha-ching.wav');
const resetSound = new Audio('566888__lennartgreen__click-metronome-atonal-high.wav');

function playClickSound() {
    clickSound.play();
}

function playResetSound() {
    resetSound.play();
}

// Add event listener to the parent element of all buttons
document.body.addEventListener('click', function (event) {
    const target = event.target;
    if (target.tagName === 'BUTTON') {
        if (target.classList.contains('copy-button')) {
            // Play click sound
            playClickSound();
            // Copy to clipboard
            const calculatorId = target.closest('.section').id;
            if (calculatorId === 'arv-mao-calculator') {
                copyARVMAOResultsToClipboard();
            } else if (calculatorId === 'seller-financing-calculator') {
                copySellerFinancingResultsToClipboard();
            }
        } else if (target.classList.contains('reset-button')) {
            // Play click sound
            playClickSound();
            // Reset calculator
            const calculatorId = target.closest('.section').id;
            if (calculatorId === 'arv-mao-calculator') {
                resetARVMAO();
            } else if (calculatorId === 'seller-financing-calculator') {
                resetSellerFinancing();
            }
        } else {
            // Play click sound
            playClickSound();
        }
    }
});

// Function to copy ARV and MAO results to clipboard
function copyARVMAOResultsToClipboard() {
    const arvMaoResults = document.querySelector(".arv-mao-results");
    const resultsContent = arvMaoResults.innerText;

    // Copy the results content to the clipboard
    navigator.clipboard.writeText(resultsContent)
        .then(() => alert('ARV and MAO results copied to clipboard'))
        .catch(err => console.error('Failed to copy ARV and MAO results: ', err));
}

// Function to copy Seller Financing results to clipboard
function copySellerFinancingResultsToClipboard() {
    const sellerFinancingResults = document.querySelector(".seller-financing-results");
    const resultsContent = sellerFinancingResults.innerText;

    // Copy the results content to the clipboard
    navigator.clipboard.writeText(resultsContent)
        .then(() => alert('Seller Financing results copied to clipboard'))
        .catch(err => console.error('Failed to copy Seller Financing results: ', err));
}

// Function to handle resetting of the calculators
function resetCalculator(calculatorId) {
    const calculatorSection = document.getElementById(calculatorId);
    const inputs = calculatorSection.querySelectorAll('input[type="text"], input[type="number"], select');

    // Reset input fields
    inputs.forEach(input => {
        input.value = '';
    });

    // Reset comps for ARV and MAO calculator
    if (calculatorId === 'arv-mao-calculator') {
        compCount = 0;
        const compsContainer = document.getElementById("comps");
        compsContainer.innerHTML = "";
    }

    // Clear results
    calculatorSection.querySelector('.results').innerHTML = '';

    // Play reset sound
    playResetSound();
}

// Add event listener to the reset buttons
document.querySelectorAll('.reset-button').forEach(button => {
    button.addEventListener('click', function(event) {
        const calculatorId = event.target.closest('.section').id;
        resetCalculator(calculatorId);
    });
});

// Call the updateDownPaymentValue function initially to set the initial display value for the down payment percentage slider
updateDownPaymentValue();
